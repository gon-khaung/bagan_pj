<?php

namespace App\Http\Controllers;

use App\Hotel;
use Illuminate\Http\Request;
use App\Pagoda;

class FrontendController extends Controller
{




}
